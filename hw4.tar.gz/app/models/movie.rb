class Movie < ActiveRecord::Base
  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end

  def self.find_by_director(arg1)
  	director = Movie.find(arg1).director
  	Movie.find_all_by_director(director)
  end
end

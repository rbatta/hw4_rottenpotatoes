FactoryGirl.define do
	factory :movie do
		title 'Alien'
		director 'Ridley Scott'
	end
end